CREATE DATABASE IF NOT EXISTS buyhomeforless CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE buyhomeforless;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(80) NOT NULL,
  role ENUM('HEAD_ADMIN', 'ADMIN', 'EMPLOYEE') NOT NULL DEFAULT 'EMPLOYEE',
  status ENUM('ACTIVE', 'DISABLED') NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS customer_accounts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, email VARCHAR(190) NOT NULL, password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(80) NOT NULL, last_name VARCHAR(80) NOT NULL, phone VARCHAR(40) NULL, address VARCHAR(240) NULL,
  subdistrict VARCHAR(120) NULL, district VARCHAR(120) NULL, province VARCHAR(120) NULL, postal_code VARCHAR(20) NULL,
  status ENUM('PENDING_VERIFICATION','ACTIVE','DISABLED','DELETED') NOT NULL DEFAULT 'PENDING_VERIFICATION', email_verified_at TIMESTAMP NULL, last_login_at TIMESTAMP NULL,
  notification_frequency ENUM('realtime','daily','none') NOT NULL DEFAULT 'realtime', marketing_preference TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_customer_accounts_email (email), INDEX idx_customer_accounts_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS listings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  slug VARCHAR(190) NOT NULL UNIQUE,
  seo_title VARCHAR(180) NULL,
  meta_description VARCHAR(320) NULL,
  seo_keywords JSON NULL,
  canonical_url VARCHAR(500) NULL,
  index_status ENUM('index', 'noindex') NOT NULL DEFAULT 'index',
  follow_status ENUM('follow', 'nofollow') NOT NULL DEFAULT 'follow',
  og_title VARCHAR(180) NULL,
  og_description VARCHAR(320) NULL,
  og_image VARCHAR(500) NULL,
  twitter_title VARCHAR(180) NULL,
  twitter_description VARCHAR(320) NULL,
  twitter_image VARCHAR(500) NULL,
  schema_type VARCHAR(80) NOT NULL DEFAULT 'RealEstateListing',
  section ENUM('BUY', 'RENT', 'SELL', 'SENIOR_HOME') NOT NULL,
  category ENUM('FORECLOSURE', 'PRE_FORECLOSURE', 'DISTRESS_PROPERTY', 'FIXER_UPPER', 'URGENT_SALE', 'FEATURED', 'NEW_LISTING') NOT NULL DEFAULT 'NEW_LISTING',
  status ENUM('DRAFT', 'PUBLISHED', 'ARCHIVED', 'DELETED') NOT NULL DEFAULT 'DRAFT',
  property_type VARCHAR(120) NULL,
  price_amount INT UNSIGNED NULL,
  currency_code VARCHAR(12) NOT NULL DEFAULT 'THB',
  buy_price INT UNSIGNED NULL,
  rent_monthly_price INT UNSIGNED NULL,
  deposit_amount INT UNSIGNED NULL,
  price_unit_label VARCHAR(80) NULL,
  description TEXT NULL,
  highlights JSON NULL,
  amenities JSON NULL,
  features JSON NULL,
  property_details JSON NULL,
  furnishing_status VARCHAR(80) NULL,
  has_air_conditioner TINYINT(1) NULL,
  has_kitchen TINYINT(1) NULL,
  bedrooms TINYINT UNSIGNED NULL,
  bathrooms TINYINT UNSIGNED NULL,
  land_size DECIMAL(12,2) NULL,
  interior_size_sqm DECIMAL(12,2) NULL,
  built_year SMALLINT UNSIGNED NULL,
  street_address VARCHAR(240) NULL,
  district VARCHAR(120) NULL,
  subdistrict VARCHAR(120) NULL,
  city VARCHAR(120) NULL,
  province VARCHAR(120) NULL,
  postal_code VARCHAR(20) NULL,
  country VARCHAR(120) NOT NULL DEFAULT 'Thailand',
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  map_search_label VARCHAR(255) NULL,
  created_by BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_listings_status_section (status, section),
  INDEX idx_listings_category (category),
  INDEX idx_listings_city_province (city, province),
  INDEX idx_listings_public_updated (status, updated_at),
  INDEX idx_listings_public_transaction_updated (status, transaction_mode, updated_at),
  INDEX idx_listings_public_location (status, province, district),
  INDEX idx_listings_public_type (status, normalized_property_type),
  INDEX idx_listings_public_category_view (status, special_category, view_type),
  INDEX idx_listings_public_sale_price (status, transaction_mode, buy_price),
  INDEX idx_listings_public_rent_price (status, transaction_mode, rent_monthly_price),
  CONSTRAINT fk_listings_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS listing_images (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  listing_id BIGINT UNSIGNED NOT NULL,
  original_name VARCHAR(190) NOT NULL,
  mime_type VARCHAR(80) NOT NULL,
  card_url VARCHAR(255) NOT NULL,
  alt_text VARCHAR(180) NULL,
  caption VARCHAR(240) NULL,
  banner_url VARCHAR(255) NOT NULL,
  detail_url VARCHAR(255) NOT NULL,
  mobile_url VARCHAR(255) NOT NULL,
  gallery_url VARCHAR(255) NOT NULL,
  sort_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
  is_cover TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_listing_images_listing_sort (listing_id, sort_order),
  CONSTRAINT fk_listing_images_listing FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SEO TODO hooks:
-- 1. Generate listing sitemap entries from listings.slug where status = 'PUBLISHED' and index_status = 'index'.
-- 2. Apply index_status/follow_status to robots meta tags and robots.txt route rules.
-- 3. Render listing canonical_url, Open Graph, Twitter/X, image alt/caption, and schema_type as page-level metadata/JSON-LD.
-- 4. Add Google Search Console verification through environment/config only; do not store Google credentials in listing records.

CREATE TABLE IF NOT EXISTS listing_faqs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  listing_id BIGINT UNSIGNED NOT NULL,
  question VARCHAR(240) NOT NULL,
  answer TEXT NOT NULL,
  sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_listing_faqs_listing_sort (listing_id, sort_order),
  CONSTRAINT fk_listing_faqs_listing FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS seller_applications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(190) NOT NULL,
  property_type VARCHAR(120) NULL,
  location VARCHAR(255) NOT NULL,
  message TEXT NULL,
  status ENUM('NEW', 'CONTACTED', 'IN_REVIEW', 'CLOSED', 'SPAM_REJECTED') NOT NULL DEFAULT 'NEW',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_seller_applications_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS customer_sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, customer_id BIGINT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL, expires_at TIMESTAMP NOT NULL, revoked_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_customer_sessions_token_hash (token_hash), INDEX idx_customer_sessions_expiry (expires_at), INDEX idx_customer_sessions_customer (customer_id),
  CONSTRAINT fk_customer_sessions_customer FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS staff_sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL, expires_at TIMESTAMP NOT NULL, revoked_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_staff_sessions_token_hash (token_hash), INDEX idx_staff_sessions_expiry (expires_at), INDEX idx_staff_sessions_user (user_id),
  CONSTRAINT fk_staff_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS customer_action_tokens (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, customer_id BIGINT UNSIGNED NOT NULL, purpose ENUM('EMAIL_VERIFICATION','PASSWORD_RESET','EMAIL_CHANGE') NOT NULL,
  token_hash CHAR(64) NOT NULL, pending_email VARCHAR(190) NULL, expires_at TIMESTAMP NOT NULL, used_at TIMESTAMP NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_customer_action_tokens_hash (token_hash), INDEX idx_customer_action_tokens_expiry (expires_at), INDEX idx_customer_action_tokens_customer_purpose (customer_id,purpose,used_at),
  CONSTRAINT fk_customer_action_tokens_customer FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS customer_favorites (
  customer_id BIGINT UNSIGNED NOT NULL, listing_id BIGINT UNSIGNED NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (customer_id,listing_id), INDEX idx_customer_favorites_listing (listing_id),
  CONSTRAINT fk_customer_favorites_customer FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE,
  CONSTRAINT fk_customer_favorites_listing FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
