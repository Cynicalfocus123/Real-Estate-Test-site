import fs from "node:fs/promises";
import path from "node:path";
import type { RowDataPacket } from "mysql2/promise";
import sharp, { type Metadata } from "sharp";
import { env } from "../config/env";
import { executeSql, queryRows } from "../db/pool";
import { ApiError } from "../utils/errors";
import { sanitizePlainText } from "../utils/sanitize";

const ALLOWED_MIME_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/avif"]);
export const MAX_IMAGE_DIMENSION = 12_000;
export const MAX_IMAGE_PIXELS = 40_000_000;

function safeBaseName(input: string) {
  const clean = sanitizePlainText(input, 80).replace(/[^a-zA-Z0-9._-]/g, "-");
  return clean || "listing-image";
}

function publicUrl(relativePath: string) {
  return `${env.PUBLIC_UPLOAD_BASE_URL.replace(/\/+$/, "")}/${relativePath.replace(/\\/g, "/")}`;
}

async function writeVariant(buffer: Buffer, target: string, width: number, height: number) {
  await sharp(buffer, { limitInputPixels: MAX_IMAGE_PIXELS, failOn: "error" })
    .rotate()
    .resize(width, height, { fit: "cover", position: "centre" })
    .webp({ quality: 84 })
    .toFile(target);
}

export async function validateListingImage(file: Express.Multer.File) {
  if (!ALLOWED_MIME_TYPES.has(file.mimetype)) throw new ApiError(400, `Unsupported image type: ${file.mimetype}`);
  let metadata: Metadata;
  try { metadata = await sharp(file.buffer, { limitInputPixels: MAX_IMAGE_PIXELS, failOn: "error" }).metadata(); }
  catch { throw new ApiError(400, "Image file is invalid or unsafe"); }
  const width = metadata.width ?? 0;
  const height = metadata.height ?? 0;
  if (!width || !height || width > MAX_IMAGE_DIMENSION || height > MAX_IMAGE_DIMENSION || width * height > MAX_IMAGE_PIXELS) {
    throw new ApiError(400, "Image dimensions are too large");
  }
}

export async function saveListingImages(listingId: number, files: Express.Multer.File[]) {
  if (!files.length) {
    throw new ApiError(400, "Select at least one image to upload");
  }
  const listingRows = await queryRows<(RowDataPacket & { id: number })[]>(
    "SELECT id FROM listings WHERE id = ? LIMIT 1",
    [listingId],
  );
  if (!listingRows.length) {
    throw new ApiError(404, "Property not found");
  }

  const countRows = await queryRows<(RowDataPacket & { count: number })[]>(
    "SELECT COUNT(*) AS count FROM listing_images WHERE listing_id = ?",
    [listingId],
  );
  const existingCount = countRows[0]?.count ?? 0;
  if (existingCount + files.length > 12) {
    throw new ApiError(400, "A listing can only have up to 12 images");
  }

  const listingDir = path.join(env.UPLOAD_DIR_ABSOLUTE, "listings", String(listingId));
  await fs.mkdir(listingDir, { recursive: true });

  const created: unknown[] = [];
  const createdFiles: string[] = [];
  for (let i = 0; i < files.length; i += 1) {
    const file = files[i];
    await validateListingImage(file);
    const base = safeBaseName(path.parse(file.originalname).name);
    const stamp = `${Date.now()}-${i + 1}`;

    const cardName = `${base}-${stamp}-card.webp`;
    const bannerName = `${base}-${stamp}-banner.webp`;
    const detailName = `${base}-${stamp}-detail.webp`;
    const mobileName = `${base}-${stamp}-mobile.webp`;
    const galleryName = `${base}-${stamp}-gallery.webp`;

    try {
      const targets = [cardName, bannerName, detailName, mobileName, galleryName].map((name) => path.join(listingDir, name));
      await writeVariant(file.buffer, targets[0], 640, 420);
      await writeVariant(file.buffer, targets[1], 1600, 500);
      await writeVariant(file.buffer, targets[2], 1280, 860);
      await writeVariant(file.buffer, targets[3], 720, 540);
      await writeVariant(file.buffer, targets[4], 1600, 1200);
      createdFiles.push(...targets);
    } catch (error) {
      await Promise.all(createdFiles.map((filePath) => fs.unlink(filePath).catch(() => undefined)));
      throw error;
    }

    const relativeBase = path.join("listings", String(listingId));
    const cardUrl = publicUrl(path.join(relativeBase, cardName));
    const bannerUrl = publicUrl(path.join(relativeBase, bannerName));
    const detailUrl = publicUrl(path.join(relativeBase, detailName));
    const mobileUrl = publicUrl(path.join(relativeBase, mobileName));
    const galleryUrl = publicUrl(path.join(relativeBase, galleryName));
    const sortOrder = existingCount + i;
    const isCover = sortOrder === 0;

    const insertResult = await executeSql(
      `INSERT INTO listing_images
      (listing_id, original_name, mime_type, card_url, banner_url, detail_url, mobile_url, gallery_url, sort_order, is_cover)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        listingId,
        safeBaseName(file.originalname),
        file.mimetype,
        cardUrl,
        bannerUrl,
        detailUrl,
        mobileUrl,
        galleryUrl,
        sortOrder,
        isCover ? 1 : 0,
      ],
    );

    created.push({
      id: Number(insertResult.insertId),
      cardUrl,
      bannerUrl,
      detailUrl,
      mobileUrl,
      galleryUrl,
      sortOrder,
      isCover,
    });
  }
  return created;
}

function getLocalFilePathFromPublicUrl(url: string) {
  const base = env.PUBLIC_UPLOAD_BASE_URL.replace(/\/+$/, "");
  if (!url.startsWith(base)) {
    return null;
  }
  const relative = url.slice(base.length).replace(/^\/+/, "");
  if (!relative) {
    return null;
  }
  return path.resolve(env.UPLOAD_DIR_ABSOLUTE, relative);
}

export async function deleteListingImageFiles(imageUrls: string[]) {
  await Promise.all(
    imageUrls.map(async (url) => {
      const localPath = getLocalFilePathFromPublicUrl(url);
      if (!localPath) {
        return;
      }
      try {
        await fs.unlink(localPath);
      } catch (error) {
        const maybeNodeError = error as NodeJS.ErrnoException;
        if (maybeNodeError.code !== "ENOENT") {
          throw error;
        }
      }
    }),
  );
}
